# Vaks Apartment - UML Class Diagram

GitHub renders the Mermaid block below automatically. Paste it into your `README.md` (or keep this file as `UML.md`).

```mermaid
classDiagram
    direction TB

    class JFrame {
        <<Swing>>
    }
    class JDialog {
        <<Swing>>
    }
    class Printable {
        <<interface>>
        +printReceiptDetails() void
    }

    class VaksJFrame {
        <<abstract>>
        +VaksJFrame()
        +VaksJFrame(int closeOperation)
    }

    class Main {
        +main(String[] args)$ void
    }

    class MainExtended {
        +userData$ UserData
        +currentUser$ UserDataBP
        -adminAccount$ UserDataBP
        +getAdminAccount()$ UserDataBP
        ~MainExtended()
    }

    class UserDataBP {
        -fullName String
        -email String
        -password String
        -phoneNumber String
        -role String
        -unitType String
        -TenantId String
        -leaseOfStay String
        -apartmentUnit String
        -moveInDate String
        -endDate String
        -gender String
        -monthRate double
        -currentBalance double
        -loginAttempts int
        -blocked boolean
        +UserDataBP(fullName, email, password, phoneNumber, role)
        +UserDataBP(... full tenant constructor)
        +getFullName() String
        +getEmail() String
        +getPassword() String
        +getPhoneNumber() String
        +getTenantId() String
        +getApartmentUnit() String
        +getMoveInDate() String
        +getEndDate() String
        +getMonthRate() double
        +getCurrentBalance() double
        +setCurrentBalance(double) void
        +getLoginAttempts() int
        +setLoginAttempts(int) void
        +isBlocked() boolean
        +setBlocked(boolean) void
    }

    class UserData {
        -Data$ ArrayList~UserDataBP~
        +UserData()
        +addUser(UserDataBP) void
        +getUsers() ArrayList~UserDataBP~
        +login(email, password) boolean
        +changePassword(email, oldPass, newPass) boolean
        +removeUser(tenantId) void
    }

    class DataStore {
        +tenantModel$ DefaultTableModel
        +unitModel$ DefaultTableModel
        +transactionModel$ DefaultTableModel
        +paymentHistoryModel$ DefaultTableModel
        +tenantPaymentHistoryModel$ DefaultTableModel
        +paymentModel$ DefaultTableModel
        +adminRecentTransactionModel$ DefaultTableModel
        +paymentComboModel$ DefaultComboBoxModel~String~
        +addPayment(date, unit, tenant, method, amount, status)$ void
        +updatePaymentStatus(rowIndex, newStatus)$ void
        +updatePaymentMethod(rowIndex, method)$ void
        +updatePaymentAmount(rowIndex, amount)$ void
        +deletePayment(rowIndex)$ void
        +updateTenantDetails(oldName, oldEmail, newName, newEmail)$ void
        +checkAndUpdateOverdueStatus(tenantEmail, dueDate)$ void
    }

    class AdminHome {
        ~apartmentPage$ ApartmentManagement
        ~adminHome$ AdminHome
        ~tenantManagement$ TenantManagement
        ~transactionHistory$ TransactionHistory
        ~fValue JLabel
        ~sValue JLabel
        ~tValue JLabel
    }

    class ApartmentManagement {
        ~apartmentPage$ ApartmentManagement
        ~adminHome$ AdminHome
        ~tenantManagement$ TenantManagement
        ~transactionHistory$ TransactionHistory
    }

    class JTFF {
        ~fie1 JTextField
        ~fie2 JTextField
        ~fie3 JTextField
        ~typeDropdown JComboBox~String~
        ~statusDropdown JComboBox~String~
        -isFieldValid(JTextField) boolean
        +JTFF(int rowIndex)
    }

    class TenantManagement {
        ~apartmentPage$ ApartmentManagement
        ~adminHome$ AdminHome
        ~tenantManagement$ TenantManagement
        ~transactionHistory$ TransactionHistory
        ~openAddTenantPopup()$ void
    }

    class EditTenant {
        ~txtId JTextField
        ~txtName JTextField
        ~txtUnit JTextField
        ~txtEmail JTextField
        -isFieldValid(JTextField) boolean
        +EditTenant(int rowIndex)
    }

    class PopUpCode {
        ~f2A JComboBox~String~
        ~ps1A JComboBox~String~
        ~btnCancel JButton
        ~btnSave JButton
        ~PopUpCode(DefaultTableModel model)
    }

    class TransactionHistory {
        ~table JTable
        ~fromDate JDateChooser
        ~toDate JDateChooser
        -dsaMergeSort(model, columnIndex, ascending, isNumeric) void
        -mergeSortHelper(data, left, right, columnIndex, ascending, isNumeric) void
        -merge(data, left, mid, right, columnIndex, ascending, isNumeric) void
        -shouldSwapDSA(o1, o2, ascending, isNumeric) boolean
    }

    class PaymentHistory {
        ~table JTable
    }

    class TenantHomeDashboard {
        ~rentAndpayment$ RentAndPayment
        ~TenantHomeDashboard()
    }

    class Account {
        -current UserDataBP
        ~Account()
    }

    class ChangePassUI {
        ~ChangePassUI()
    }

    class RentAndPayment {
        ~rentAndpayment$ RentAndPayment
        -payment Payment
        ~tabs JTable
        -getNextDueDate() LocalDate
    }

    class Payment {
        -rentAndpayment RentAndPayment
        -paymentConfirmation PaymentConfirmation
        -t1 JTextField
        +getPaymentAmount() double
        -getNextDueDate() LocalDate
    }

    class PaymentConfirmation {
        -payment Payment
        ~PaymentConfirmation(double paymentAmount)
        -getNextDueDate() LocalDate
    }

    class PaymentSummary {
        ~PaymentSummary(double paymentAmount, String dueDateStr)
        -getNextDueDate() LocalDate
    }

    class ReceiptDialog {
        +ReceiptDialog(parent, receiptNo, transId, tenantName, tenantId, unitNo, category, totalBalance, method, amountPaid, dueDate, paymentDate, status)
        +printReceiptDetails() void
    }

    %% Inheritance / realization
    JFrame <|-- VaksJFrame
    VaksJFrame <|-- MainExtended
    VaksJFrame <|-- AdminHome
    VaksJFrame <|-- ApartmentManagement
    VaksJFrame <|-- JTFF
    VaksJFrame <|-- TenantManagement
    VaksJFrame <|-- EditTenant
    VaksJFrame <|-- PopUpCode
    VaksJFrame <|-- TransactionHistory
    VaksJFrame <|-- PaymentHistory
    VaksJFrame <|-- TenantHomeDashboard
    VaksJFrame <|-- Account
    VaksJFrame <|-- ChangePassUI
    VaksJFrame <|-- RentAndPayment
    VaksJFrame <|-- Payment
    VaksJFrame <|-- PaymentConfirmation
    VaksJFrame <|-- PaymentSummary
    JDialog <|-- ReceiptDialog
    Printable <|.. ReceiptDialog

    %% Data model
    UserData "1" o-- "*" UserDataBP : stores
    MainExtended --> UserData : userData
    MainExtended --> UserDataBP : currentUser / adminAccount
    Main ..> MainExtended : creates

    %% Login navigation
    MainExtended ..> AdminHome : admin login
    MainExtended ..> TenantHomeDashboard : tenant login

    %% Admin navigation
    AdminHome ..> TenantManagement
    AdminHome ..> ApartmentManagement
    AdminHome ..> TransactionHistory
    TransactionHistory ..> PaymentHistory : Billing Status
    TenantManagement ..> EditTenant : edit
    TenantManagement ..> PopUpCode : add tenant
    ApartmentManagement ..> JTFF : edit unit

    %% Tenant navigation
    TenantHomeDashboard ..> RentAndPayment
    TenantHomeDashboard ..> Account
    Account ..> ChangePassUI
    RentAndPayment ..> Payment : Pay Now / Pay Overdue
    RentAndPayment ..> ReceiptDialog : View Receipt
    Payment ..> PaymentConfirmation
    PaymentConfirmation ..> PaymentSummary

    %% Shared data usage
    AdminHome ..> DataStore
    ApartmentManagement ..> DataStore
    TenantManagement ..> DataStore
    PopUpCode ..> UserData : addUser
    PopUpCode ..> UserDataBP : creates
    TransactionHistory ..> DataStore
    PaymentHistory ..> DataStore
    RentAndPayment ..> DataStore
    Payment ..> DataStore
    PaymentConfirmation ..> DataStore
    PaymentSummary ..> DataStore
    Account --> UserDataBP : current
```

## Legend

| Arrow | Meaning |
|-------|---------|
| `<\|--` | Inheritance (extends) |
| `<\|..` | Implements an interface |
| `o--` | Aggregation (has many) |
| `-->` | Association (holds a reference) |
| `..>` | Dependency (opens / uses) |
| `$` suffix | `static` member |
| `+` `-` `~` | public / private / package-private |
